/*
 * File:   main.c
 * Author: Chloe Fulbrook, Ethan Lee, Devon Calvin
 *
 * Created FOR ENCM 511
 * PLEASE ADD DATE CREATED HERE: 2025-10-02
 * 
 * FAILURE TO UPDATE THIS HEADER WITH YOUR GROUP MEMBER NAMES
 * MAY RESULT IN PENALTIES
 */

// FSEC
#pragma config BWRP = OFF    //Boot Segment Write-Protect bit->Boot Segment may be written
#pragma config BSS = DISABLED    //Boot Segment Code-Protect Level bits->No Protection (other than BWRP)
#pragma config BSEN = OFF    //Boot Segment Control bit->No Boot Segment
#pragma config GWRP = OFF    //General Segment Write-Protect bit->General Segment may be written
#pragma config GSS = DISABLED    //General Segment Code-Protect Level bits->No Protection (other than GWRP)
#pragma config CWRP = OFF    //Configuration Segment Write-Protect bit->Configuration Segment may be written
#pragma config CSS = DISABLED    //Configuration Segment Code-Protect Level bits->No Protection (other than CWRP)
#pragma config AIVTDIS = OFF    //Alternate Interrupt Vector Table bit->Disabled AIVT

// FBSLIM
#pragma config BSLIM = 8191    //Boot Segment Flash Page Address Limit bits->8191

// FOSCSEL
#pragma config FNOSC = FRC    //Oscillator Source Selection->Internal Fast RC (FRC)
#pragma config PLLMODE = PLL96DIV2    //PLL Mode Selection->96 MHz PLL. Oscillator input is divided by 2 (8 MHz input)
#pragma config IESO = OFF    //Two-speed Oscillator Start-up Enable bit->Start up with user-selected oscillator source

// FOSC
#pragma config POSCMD = NONE    //Primary Oscillator Mode Select bits->Primary Oscillator disabled
#pragma config OSCIOFCN = ON    //OSC2 Pin Function bit->OSC2 is general purpose digital I/O pin
#pragma config SOSCSEL = OFF    //SOSC Power Selection Configuration bits->Digital (SCLKI) mode
#pragma config PLLSS = PLL_FRC    //PLL Secondary Selection Configuration bit->PLL is fed by the on-chip Fast RC (FRC) oscillator
#pragma config IOL1WAY = ON    //Peripheral pin select configuration bit->Allow only one reconfiguration
#pragma config FCKSM = CSECMD    //Clock Switching Mode bits->Clock switching is enabled,Fail-safe Clock Monitor is disabled

// FWDT
#pragma config WDTPS = PS32768    //Watchdog Timer Postscaler bits->1:32768
#pragma config FWPSA = PR128    //Watchdog Timer Prescaler bit->1:128
#pragma config FWDTEN = ON_SWDTEN    //Watchdog Timer Enable bits->WDT Enabled/Disabled (controlled using SWDTEN bit)
#pragma config WINDIS = OFF    //Watchdog Timer Window Enable bit->Watchdog Timer in Non-Window mode
#pragma config WDTWIN = WIN25    //Watchdog Timer Window Select bits->WDT Window is 25% of WDT period
#pragma config WDTCMX = WDTCLK    //WDT MUX Source Select bits->WDT clock source is determined by the WDTCLK Configuration bits
#pragma config WDTCLK = LPRC    //WDT Clock Source Select bits->WDT uses LPRC

// FPOR
#pragma config BOREN = ON    //Brown Out Enable bit->Brown Out Enable Bit
#pragma config LPCFG = OFF    //Low power regulator control->No Retention Sleep
#pragma config DNVPEN = ENABLE    //Downside Voltage Protection Enable bit->Downside protection enabled using ZPBOR when BOR is inactive

// FICD
#pragma config ICS = PGD1    //ICD Communication Channel Select bits->Communicate on PGEC1 and PGED1
#pragma config JTAGEN = OFF    //JTAG Enable bit->JTAG is disabled

// FDEVOPT1
#pragma config ALTCMPI = DISABLE    //Alternate Comparator Input Enable bit->C1INC, C2INC, and C3INC are on their standard pin locations
#pragma config TMPRPIN = OFF    //Tamper Pin Enable bit->TMPRN pin function is disabled
#pragma config SOSCHP = ON    //SOSC High Power Enable bit (valid only when SOSCSEL = 1->Enable SOSC high power mode (default)
#pragma config ALTI2C1 = ALTI2CEN    //Alternate I2C pin Location->SDA1 and SCL1 on RB9 and RB8


#include "xc.h"

#include "init.h"

// define the buttons for easier readability
#define PB1     PORTBbits.RB8
#define PB0     PORTAbits.RA4
#define PB2     PORTBbits.RB9   

// define a debounce macro for ease of adjustment and readability
#define DEBOUNCE 10

// define some macros for the LED0 blink times
#define tmr_025 3906
#define tmr_05 7812

// these are volatile flags for the push buttons to help track the event states
volatile uint16_t PB0_event;
volatile uint16_t PB1_event;
volatile uint16_t PB2_event;

// another volatile flag to track whether PB2 is currently in debounce
volatile uint16_t debounce_progress;

// an array to track the halving of the duration of the LED1 blinking
uint16_t PB2_times[6] = {62500, 31250, 15625, 7812, 3906, 1953};
                        // 4s,   2s,   1s,    0.5s, 0.25s, 0.125s
// controls the index of the LED1 blinking array to track the PB2 inputs
uint16_t PB2_times_index = 0;



int main(void) {
    
    /** This is usually where you would add run-once code
     * e.g., peripheral initialization. For the first labs
     * you might be fine just having it here. For more complex
     * projects, you might consider having one or more initialize() functions
     */
    
    ANSELA = 0x0000; /* keep this line as it sets I/O pins that can also be analog to be digital */
    ANSELB = 0x0000; /* keep this line as it sets I/O pins that can also be analog to be digital */
    
    // from the header file, initialize the timers and IOs
    IOinit();
    timerInit();
    
    // create the states for the FSM, and initialize to the off state
    typedef enum{
        STATE_OFF, 
        STATE_PB0,
        STATE_PB1, 
        STATE_PB0_PB1        
    } state_t;
    state_t state = STATE_OFF;
    
    
    // clear the event flags 
    PB0_event = 0;
    PB1_event = 0;
    PB2_event = 0;

    
    while(1) {    // being superloop 

        switch(state){
            case STATE_OFF:
                // original state, no buttons pressed, no LEDs active
                
                // turn all LEDs off
                LED0 = 0;
                LED1 = 0; 
                LED2 = 0;

                Idle();                 // put CPU to idle
                delay_ms(DEBOUNCE);     // a debounce delay to help allow inputs to stabilize before reading
                
                if(PB0_event == 1 && PB1_event == 1){
                    // if an event has occurred on both PB0 and PB1 (both pressed simultaneously from off state)
                    // expect to start seeing the 0.5s blinking of LED0
                    
                    // turn LED0 on immediately, ensure LED1 is off
                    LED0 = 1;
                    LED1 = 0;

                    // initialize timer 3 to the 0.5s count period, and set start count to 0
                    PR3 = tmr_05;    
                    TMR3 = 0;
                    T3CONbits.TON = 1;      // turn on timer

                    state = STATE_PB0_PB1;  // move to the next state (where both PB0 and 1 are active)
                    break;
                }
                else if(PB0_event == 1){
                    // if an event has occurred on only PB0
                    // expect to start seeing the 0.25s blinking on LED0
                    
                    // turn LED0 on immediately, ensure LED1 off
                    LED0 = 1;
                    LED1 = 0;

                    // initialize timer 3 to the 0.25s count period, set start count to 0
                    PR3 = tmr_025; 
                    TMR3 = 0;
                    T3CONbits.TON = 1;      // turn on timer

                    state = STATE_PB0;      // move to next state (only PB0 active)
                    break;
                }
                else if(PB1_event == 1){
                    // if an event has occurred on only PB1
                    // expect to move to the variable duration state of LED1 with whatever period is currently active
                    
                    // turn LED1 on immediately, ensure LED0 is off
                    // ensures that we dont have to wait 4s of off time before light turns on
                    LED1 = 1;
                    LED0 = 0;
                    
                    // initialize timer 3 to whatever count period is currently specified by PB2
                    // also turn start count to 0
                    PR3 = PB2_times[PB2_times_index];
                    TMR3 = 0;
                    T3CONbits.TON = 1;      // turn on timer
                    
                    state = STATE_PB1;      // move to next state (only PB1 active)
                    break;
                }

                break;
                
            case STATE_PB0:
                // state where PB0 is currently pressed
                // should see LED0 blinking at 0.25s intervals
                
                Idle();                 // put CPU to idle
                delay_ms(DEBOUNCE);     // short debounce delay to allow inputs to stabilize before reading

                if(PB0_event == 0){
                    // if PB0 is released (no longer has an event)
                    // expect LEDs to turn off, return to Idle (STATE_OFF)
                    
                    LED0 = 0;               // turn off LED0 immediately
                    T3CONbits.TON = 0;      // turn timer 3 off
                    state = STATE_OFF;      // move to next state (no buttons active)
                    break;
                }
                else if(PB1_event == 1){
                    // if PB1 has an event while PB0 is held
                    // expect to see blinking period change to 0.5s
                    // note no need to alter LED states, as they are held
                    
                    PR3 = tmr_05;       // set the timer3 count to the 0.5s tick
                    TMR3 = 0;           // set count start to 0
                    T3CONbits.TON = 1;  // enable timer
                        // ^^shouldn't be necessary, but if a glitch in state transition occurred this helps (i think)

                    state = STATE_PB0_PB1;      // move to next state (both buttons active)
                    break;
                }

                break;
                
                
                
            case STATE_PB1:
                // state where PB1 is currently pressed
                // should see LED1 blinking at a variable rate determined by the PB2 times array

                Idle();             // put CPU into idle
                delay_ms(DEBOUNCE); // short debounce delay to allow inputs to stabilize
                
                if (PB2_event == 1) {
                    // if an event occurs on PB2, need to update the timer period
                    // this if() helps to keep track of that WHILE PB1 is being held
                    // will see changes in the blinking period as this runs
                    
                    PB2_event = 0;                      // clear event flag
                    PR3 = PB2_times[PB2_times_index];   // update timer period to correspond to PB2 increments
                    TMR3 = 0;                           // set count start to 0
                    T3CONbits.TON = 1;                  // turn on timer 3
                }
                 

                if(PB1_event == 0){
                    // if PB1 is released (no longer an event, no buttons are pressed)
                    // expect LEDs off, return to the idle STATE_OFF state
                    
                    // ensure the LEDs get turned off
                    LED1 = 0;
                    LED0 = 0;

                    T3CONbits.TON = 0;  // turn the timer off
                    state = STATE_OFF;  // transition to the off state
                    break;
                }

                else if(PB0_event == 1){
                    // if PB0 has an event WHILE PB1 is being held
                    // expect LED1 to turn off, LED0 to blink at 0.5s intervals
                    
                    LED1 = 0;       // turn LED1 off immediately
                    LED0 = 1;       // turn LED0 on immediately

                    PR3 = tmr_05;       // set the timer count to the 0.5s ticks
                    TMR3 = 0;           // set count start to 0
                    T3CONbits.TON = 1;  // turn on timer 3

                    state = STATE_PB0_PB1;  // transition to the both button held state
                    break;
                }

                break;
                
                
            case STATE_PB0_PB1:
                // state where both PB0 and PB1 are currently held
                // expect to see LED0 blinking at a 0.5s rate
                
                Idle();             // put CPU to idle
                delay_ms(DEBOUNCE); // short debounce delay to allow inputs to stabilize

                if(PB0_event == 0 && PB1_event == 0){
                    // if both buttons are released simultaneously (no events)
                    // expect to return to idle STATE_OFF and LEDs turn off
                    
                    // turn the LEDs off
                    LED0 = 0;
                    LED1 = 0;
                    T3CONbits.TON = 0;      // turn timer3 off

                    state = STATE_OFF;      // transition back to idle state
                    break;
                }

                else if(PB1_event == 0){
                    // if PB1 is released while PB0 is still held
                    // expect to see the LED0 blink period to change to 0.25s
                    
                    LED1 = 0;           // ensure LED1 is off
                    
                    PR3 = tmr_025;      // set the timer count to the 0.25 ticks
                    TMR3 = 0;           // set the timer start to 0
                    T3CONbits.TON = 1;  // enable the timer

                    state = STATE_PB0;  // transition to the only PB0 active state
                    break;
                }

                else if(PB0_event == 0){
                    // if PB0 is released while PB1 is still held
                    // expect to see LED1 turn on and blink at the variable rate defined by PB2
                    
                    // immediately turn LED0 off and LED1 on
                    LED0 = 0;
                    LED1 = 1;

                    PR3 = PB2_times[PB2_times_index];   // set the timer count to the rate set by the PB2 incrementing
                    TMR3 = 0;                           // set the timer start to 0
                    T3CONbits.TON = 1;                  // turn on the timer

                    state = STATE_PB1;                  // transition to the only PB1 active state
                    break;
                }
                break;
                
            default:
                break;
 
                
        } // end switch statement

    } // end while(1)
    
    return 0;
} // end main()


// Interrupt for delay function on Timer 1
void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void){
    /*
     * used as part of the delay function to pull the CPU out of idle
     * necessary because other interrupts were disabled in the delay function
     */
    IFS0bits.T1IF = 0;      // clear the flag
    T1CONbits.TON = 0;      // turn off the timer
}

// Timer 2 interrupt subroutine
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    /*
     * used to control the debouncing of PB2 to avoid stepping through multiple states on one press
     * also holds the incrementing of the PB2_times_index to control the LED1 blink rate
     * this is done to ensure that the state of blink rate is not forgotten
     */
    
    IFS0bits.T2IF = 0;      // clear interrupt flag
    T2CONbits.TON = 0;      // disable the timer
    IEC0bits.T2IE = 0;      // disable the interrupt
    
    if(!PORTBbits.RB9){ 
        // if PB2 is pressed
        
        PB2_event = 1;      // flag the PB2 event (checked in main)
        
        PB2_times_index++;          // increment the times index
        if(PB2_times_index == 6){   
            // if the index will step beyond the declared array:
            PB2_times_index = 0;    // reset the index step back to zero
        }
    }
    debounce_progress = 0;      // turn off the debounce progress flag
}

void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void){
    /*
     * used to control the blinking of the LEDs
     * this timer is used no matter which buttons are controlling the blinking
     * (I did this so that the other timers are available for other uses, could have done them separately)
     */
    IFS0bits.T3IF = 0;      // clear the interrupt flag
    
    if(PB1_event && PB0_event){
        // if both buttons are having an event (pressed)
        LED0 ^= 1;      // toggle LED0
    }
    else if(PB1_event){
        // if only button 1 is having an event (pressed)
        LED1 ^= 1;      // toggle LED1
    }
    else if(PB0_event){
        // if only button 0 is having an event (pressed)
        LED0 ^= 1;      // toggle LED0
    }
}

void __attribute__ ((interrupt, no_auto_psv)) _IOCInterrupt(void) {
    /*
     * this is the IOC interrupt ISR. There is only one ISR for this, so handling is important
     * this ISR is entered whenever there is a button press (event) on any button
     * whether the button events are posedge or negedge triggered is defined in the IOinit() function
     */
    
    // button interrupts on PORTA
    if(IOCSTATbits.IOCPAF){
        // if the IOCSTAT register has the porta flag high
        if(!PORTAbits.RA4){     // RA4 (PB0) went low
            // this occurs after the negedge interrupt, so button is held
            PB0_event = 1;      // flag an event on PB0
        }
        else {          // if button not currently pressed (pin high?)
            // this occurs after the posedge interrupt, so button released
            PB0_event = 0;      // clear the event flag on PB0
        }
        
        IOCSTATbits.IOCPAF = 0; // clear the porta flag in the status register
    }
    
    // button interrupts on PORTB
    if(IOCSTATbits.IOCPBF){ 
        // if the IOCSTAT register has the portb flag high
        
        if(!PORTBbits.RB8){     // RB8 (PB1) went low
            // this occurs after the negedge interrupt, so button is held
            PB1_event = 1;      // flag an event on PB1
        }
        else {      // if button not currently pressed (pin high)
            // this occurs after the posedge interrupt, so button released
            PB1_event = 0;      // clear the event flag on PB0
        }
        
        if(!PORTBbits.RB9 && debounce_progress == 0){   // for PB2 on RB9
            // if PB2 is currently pressed AND we are not currently in debounce
            // essentially here the goal is to wait out the debounce period of the button
            // want to wait for a stable input so the PB2 period incrementing of LED1 only steps once per press
            
            debounce_progress = 1;      // set the debounce progress flag high (debounce in progress)
            
            TMR2 = 0;               // set the count start to 0 
            PR2 = 781;              // set the timer period to approx 50ms 
                                    // this seems to be a fine debounce time for our application
            IFS0bits.T2IF = 0;      // clear the interrupt flag
            IEC0bits.T2IE = 1;      // enable the interrupt
            T2CONbits.TON = 1;      // turn on the timer
            
            // from here, we wait for the ISR to register once T2 has counted for 50ms
            // its there that the variable rate is incremented and saved
        }
        IOCSTATbits.IOCPBF = 0;     // clear the portb flag on the status register
    }
    
    IFS1bits.IOCIF = 0;     // clear the global IOC flag
}



