#include "adc.h"
#include "xc.h"


void ADC1_init(void){

    AD1CON2bits.PVCFG = 0;      // positve voltage reference to AVDD
    AD1CON2bits.NVCFG0 = 0;     // negative voltage reference to AVSS
    
    AD1CHSbits.CH0NA = 0;       // neg ref to Vss for channel a
    AD1CHSbits.CH0SA = 5;       // pos ref to AN5 (pin7) for channel a
    
    AD1CON3bits.ADCS = 0xFF;    // set to 256*Tcy
    // DMAEN, ASEN, SMPI are 0
    
    AD1CON3bits.ADRC = 0;       // use system clock
    
    AD1CON1bits.SSRC = 7;       // set to auto-convert
    AD1CON3bits.SAMC = 0b11111; // set to auto sample 31 Tad
    AD1CON1bits.FORM = 0;       // absolute decimal result
    AD1CON1bits.MODE12 = 0;     // 10 bit mode
    
    AD1CON1bits.ASAM = 1;       // auto sample (or can manually set)
        
}

uint16_t do_ADC(void){
    uint16_t result = 0;    // variable for result
    while(!(AD1CON1bits.DONE)){}    // waiting for the conversion to be done
    result = ADC1BUF0;      // get the result
    return result;          // return the result
}


uint16_t do_ADC_avg(uint8_t samples){
    uint32_t sum = 0;   // track the sum. this needs to be uint32 cause the sum may overflow
    for(uint8_t i = 0; i < samples; i++){
        // loop through the number of samples to track
        sum += do_ADC();    // add to the sum
    }
    AD1CON1bits.ADON = 0;   // turn off the ADC when done sampling
    return (uint16_t)(sum / samples);   // divide to get the average value, and cast back to a uint16
}