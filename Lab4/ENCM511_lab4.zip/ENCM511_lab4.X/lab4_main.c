/*
 * File:   main.c
 * Author: Chloe Fulbrook, Ethan Lee, Devon Calvin
 *
 * Created FOR ENCM 511
 * PLEASE ADD DATE CREATED HERE: 2025-10-28
 * 
 * FAILURE TO UPDATE THIS HEADER WITH YOUR GROUP MEMBER NAMES
 * MAY RESULT IN PENALTIES
 */

// FSEC
#pragma config BWRP = OFF    //Boot Segment Write-Protect bit->Boot Segment may be written
#pragma config BSS = DISABLED    //Boot Segment Code-Protect Level bits->No Protection (other than BWRP)
#pragma config BSEN = OFF    //Boot Segment Control bit->No Boot Segment
#pragma config GWRP = OFF    //General Segment Write-Protect bit->General Segment may be written
#pragma config GSS = DISABLED    //General Segment Code-Protect Level bits->No Protection (other than GWRP)
#pragma config CWRP = OFF    //Configuration Segment Write-Protect bit->Configuration Segment may be written
#pragma config CSS = DISABLED    //Configuration Segment Code-Protect Level bits->No Protection (other than CWRP)
#pragma config AIVTDIS = OFF    //Alternate Interrupt Vector Table bit->Disabled AIVT

// FBSLIM
#pragma config BSLIM = 8191    //Boot Segment Flash Page Address Limit bits->8191

// FOSCSEL
#pragma config FNOSC = FRC    //Oscillator Source Selection->Internal Fast RC (FRC)
#pragma config PLLMODE = PLL96DIV2    //PLL Mode Selection->96 MHz PLL. Oscillator input is divided by 2 (8 MHz input)
#pragma config IESO = OFF    //Two-speed Oscillator Start-up Enable bit->Start up with user-selected oscillator source

// FOSC
#pragma config POSCMD = NONE    //Primary Oscillator Mode Select bits->Primary Oscillator disabled
#pragma config OSCIOFCN = ON    //OSC2 Pin Function bit->OSC2 is general purpose digital I/O pin
#pragma config SOSCSEL = OFF    //SOSC Power Selection Configuration bits->Digital (SCLKI) mode
#pragma config PLLSS = PLL_FRC    //PLL Secondary Selection Configuration bit->PLL is fed by the on-chip Fast RC (FRC) oscillator
#pragma config IOL1WAY = ON    //Peripheral pin select configuration bit->Allow only one reconfiguration
#pragma config FCKSM = CSECMD    //Clock Switching Mode bits->Clock switching is enabled,Fail-safe Clock Monitor is disabled

// FWDT
#pragma config WDTPS = PS32768    //Watchdog Timer Postscaler bits->1:32768
#pragma config FWPSA = PR128    //Watchdog Timer Prescaler bit->1:128
#pragma config FWDTEN = ON_SWDTEN    //Watchdog Timer Enable bits->WDT Enabled/Disabled (controlled using SWDTEN bit)
#pragma config WINDIS = OFF    //Watchdog Timer Window Enable bit->Watchdog Timer in Non-Window mode
#pragma config WDTWIN = WIN25    //Watchdog Timer Window Select bits->WDT Window is 25% of WDT period
#pragma config WDTCMX = WDTCLK    //WDT MUX Source Select bits->WDT clock source is determined by the WDTCLK Configuration bits
#pragma config WDTCLK = LPRC    //WDT Clock Source Select bits->WDT uses LPRC

// FPOR
#pragma config BOREN = ON    //Brown Out Enable bit->Brown Out Enable Bit
#pragma config LPCFG = OFF    //Low power regulator control->No Retention Sleep
#pragma config DNVPEN = ENABLE    //Downside Voltage Protection Enable bit->Downside protection enabled using ZPBOR when BOR is inactive

// FICD
#pragma config ICS = PGD1    //ICD Communication Channel Select bits->Communicate on PGEC1 and PGED1
#pragma config JTAGEN = OFF    //JTAG Enable bit->JTAG is disabled

// FDEVOPT1
#pragma config ALTCMPI = DISABLE    //Alternate Comparator Input Enable bit->C1INC, C2INC, and C3INC are on their standard pin locations
#pragma config TMPRPIN = OFF    //Tamper Pin Enable bit->TMPRN pin function is disabled
#pragma config SOSCHP = ON    //SOSC High Power Enable bit (valid only when SOSCSEL = 1->Enable SOSC high power mode (default)
#pragma config ALTI2C1 = ALTI2CEN    //Alternate I2C pin Location->SDA1 and SCL1 on RB9 and RB8


#include "xc.h"
#include "uart.h"
#include "init.h"
#include "adc.h"
#include "lab4_functions.h"

// variables used for the logic in the timer 2 to properly detect button edges (last valid, before debounce, after debounce)
// same as last lab
uint16_t PB0_LV = 1;
uint16_t PB1_LV = 1;
uint16_t PB2_LV = 1;

uint16_t PB0_BD;
uint16_t PB1_BD;
uint16_t PB2_BD;

uint16_t PB0_AD;
uint16_t PB1_AD;
uint16_t PB2_AD;

// variables to set default states 
volatile uint16_t begin_flag = 0;
volatile state_t state = STATE_BEGIN;

volatile mode_t mode = MODE_DEC;
volatile mode_t prev_mode = MODE_DEC;

volatile char bar_char = '=';


int main(void) {
    
    /** This is usually where you would add run-once code
     * e.g., peripheral initialization. For the first labs
     * you might be fine just having it here. For more complex
     * projects, you might consider having one or more initialize() functions
     */
    
    ANSELA = 0x0000; /* keep this line as it sets I/O pins that can also be analog to be digital */
    ANSELB = 0x0000; /* keep this line as it sets I/O pins that can also be analog to be digital */
    
    ANSELB |= 0b1000; // set RB3 (pin 7) to be analog input 
    
    // initializer functions
    InitUART2();
    IOinit();
    timerInit();
    ADC1_init();
    
    // variable definitions to store the current and previous adc results
    uint16_t adc_res;
    uint16_t prev_adc_res = 0;
    
    // to track the previous bar character for comparison
    char prev_bar_char = '=';
    
    // set the timer start and stop counts for 0.25s
    TMR3 = 0;
    PR3 = blink_025;
    
    while(1) {
        
        switch(state){
            case STATE_BEGIN:
                if(!begin_flag){
                    // if not currently counting, start the timer to count
                    // this helps to stabilize by only sampling/updating the ISR at a set interval
                    // the state will transition in the T3 ISR
                    begin_flag = 1;         // we set the flag
                    T3CONbits.TON = 1;      // and turn timer on
                }
                break;
                
            case STATE_SAMPLE:
                // handle the sampling of the adc
                adc_res = do_ADC_avg(8);    // get the adc result as an average to help w stability
                
                state = STATE_DISPLAY;      // transition to the display state
                break;
                      
            case STATE_DISPLAY:
                // deal with the UART display
                if(prev_adc_res != adc_res || prev_mode != mode || prev_bar_char != bar_char){
                    // if any of the result of the adc, the mode, or the bar display character have changed
                    // then we re-display the screen. This helps to avoid unnecessary fluctuations in the display to make it more stable
                    display_func(adc_res, mode);
                }
                // then store the current states as the prev. states for comparison
                prev_adc_res = adc_res;
                prev_mode = mode;
                prev_bar_char = bar_char;
                
                state = STATE_BEGIN;    // transition to the begin state
                break;
        } // end switch(state)
    }   // end while(1)
    return 0;
}   // end main()


// Timer 2 interrupt subroutine
void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void){
    /*
     * used to control the debouncing of buttons 
     * also decides on the current state of the buttons to appropriately modify the bar character
     */

    IFS0bits.T2IF = 0;      // clear interrupt flag
    T2CONbits.TON = 0;      // disable the timer
    IEC0bits.T2IE = 0;      // disable the interrupt

    // this chunk is the same as from last time!!!!
    if(PORTAbits.RA4 == PB0_BD){
        // if the current value of PB0 is the same as the one set immediately as the IOC triggered, 
        // the value has stabilized and the after debounce value can be set
        PB0_AD = PB0_BD;
    }
    else{
        // otherwise default the value 
        PB0_AD = 1;
    }
    
    if(PORTBbits.RB8 == PB1_BD){
        // same logic as above but for PB1
        PB1_AD = PB1_BD;
    }
    else{
        PB1_AD = 1;
    }
    
    if(PORTBbits.RB9 == PB2_BD){
        // same but for PB2
        PB2_AD = PB2_BD;
    }
    else{
        PB2_AD = 1;
    }
    
    // this logic ignores multiple button presses, only updating the bar if a single button clicked
    if((PB0_AD == 0 && PB0_LV == 1) && (PB1_AD == 0 && PB1_LV == 1) && (PB2_AD == 0 && PB2_LV == 1)){
        // now if all three buttons have gone low and their last valid values were high 
        // they have all been effectively pressed
    }
    else if((PB0_AD == 0 && PB0_LV == 1) && (PB1_AD == 0 && PB1_LV == 1)){
        // if PB0 and PB1 have both gone low and their last valid values were high,
        // they have been effectively pressed 
    }
    else if((PB0_AD == 0 && PB0_LV == 1) && (PB2_AD == 0 && PB2_LV == 1)){
        // same as above, except looking at PB0 and PB2
    }
    else if((PB1_AD == 0 && PB1_LV == 1) && (PB2_AD == 0 && PB2_LV == 1)){
        // same as above except looking at PB1 and PB2
    }
    
    // note that the following detects the rising edge after the falling edge, so this is a CLICK
    // not a press! 
    else if(PB0_AD == 1 && PB0_LV == 0 && PB1_AD == 1 && PB2_AD == 1 && PB1_LV == 1 && PB2_LV == 1){
        // now if PB0's last valid value was low and has since gone high, 
        // AND the other buttons have been stable at a high voltage (i.e. not clicked)
        // we set the char for the bar to be an =
        bar_char = '=';
    }
    else if(PB1_AD == 1 && PB1_LV == 0 && PB0_AD == 1 && PB2_AD == 1 && PB0_LV == 1 && PB2_LV == 1){
        // the same as above but its for PB1 detection
        // set the char for the bar to be x
        bar_char = 'x';
    }
    else if(PB2_AD == 1 && PB2_LV == 0 && PB0_AD == 1 && PB1_AD == 1 && PB0_LV == 1 && PB1_LV == 1){
        // same again but for PB2 detection
        // set the char for the bar to be #
        bar_char = '#';
    }
    
    // save the after-debounce value as the last valid state for each button
    PB0_LV = PB0_AD;
    PB1_LV = PB1_AD;
    PB2_LV = PB2_AD;
 
}

void __attribute__((interrupt, no_auto_psv)) _T3Interrupt(void){
    /*
     * used to control the wait period of the adc so we only get a new sample (only enter state sample)
     * every 0.25s. this helps with stability
     */
    
    TMR3 = 0;               // reset the timer start count
    IFS0bits.T3IF = 0;      // clear the interrupt flag

    AD1CON1bits.ADON = 1;   // turn on the ADC
        
    T3CONbits.TON = 0;      // turn off the timer
    begin_flag = 0;         // turn off the begin flag 
    
    state = STATE_SAMPLE;   // transition to the sampling state
}

void __attribute__ ((interrupt, no_auto_psv)) _IOCInterrupt(void) {
    /*
     * this is the IOC interrupt ISR. There is only one ISR for this, so handling is important
     * this ISR is entered whenever there is a button press (event) on any button
     * whether the button events are posedge or negedge triggered is defined in the IOinit() function
     * for lab 4, we detect both pos and negedges and then handle them in the timer2 isr above
     * Note this is the same IOC as from previous lab. 
     */
    
    if(IOCFAbits.IOCFA4){
        // if the interrupt occurred on RA4 (PB0)
        PB0_BD = PORTAbits.RA4;     // pre-debounce state of RA4 (immediately as IOC triggers)
        TMR2 = 0;               // set the count start to 0 
        PR2 = debounce_50m;     // set the timer period to approx 50ms 
                                // this seems to be a fine debounce time for our application
        IFS0bits.T2IF = 0;      // clear the interrupt flag
        IEC0bits.T2IE = 1;      // enable the interrupt
        T2CONbits.TON = 1;      // turn on the timer
        
        IOCFAbits.IOCFA4 = 0;   // clear the flag on the RA4 pin
    }
    
    if(IOCFBbits.IOCFB8){
        // if the interrupt occurred on RB8 (PB1)
        PB1_BD = PORTBbits.RB8; // pre-debounce state of RB8 (immediately as IOC triggers)
        TMR2 = 0;               // set the count start to 0 
        PR2 = debounce_50m;     // set the timer period to approx 50ms 
                                // this seems to be a fine debounce time for our application
        IFS0bits.T2IF = 0;      // clear the interrupt flag
        IEC0bits.T2IE = 1;      // enable the interrupt
        T2CONbits.TON = 1;      // turn on the timer
        
        IOCFBbits.IOCFB8 = 0;   // clear flag on RB8 pin
    }
    
    if(IOCFBbits.IOCFB9){
        // if the interrupt occurred on RB9 (PB2)
        PB2_BD = PORTBbits.RB9; // pre-debounce state of RB9 (immediately as IOC triggers))
        TMR2 = 0;               // set the count start to 0 
        PR2 = debounce_50m;     // set the timer period to approx 50ms 
                                // this seems to be a fine debounce time for our application
        IFS0bits.T2IF = 0;      // clear the interrupt flag
        IEC0bits.T2IE = 1;      // enable the interrupt
        T2CONbits.TON = 1;      // turn on the timer
        
        IOCFBbits.IOCFB9 = 0;   // clear flag on RB9 pin   
    }
    IFS1bits.IOCIF = 0;  // clear global IOC flags  
}

