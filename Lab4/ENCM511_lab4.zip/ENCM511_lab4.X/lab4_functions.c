#include "xc.h"
#include "lab4_functions.h"


void bar_graph(uint16_t adc_res, char c){
    // a function to print the bar graph based on the result of the adc and the declared character
    uint16_t num_bars = adc_res / 32;   // divide into 32 increments, giving a max of 32 bars of display
    XmitUART2(c, num_bars);     // char c can be used to change the bar character
    XmitUART2(' ', 1);          // a space for display help
}


void display_func(uint16_t adc_res, mode_t mode){
    // a function that handles the actual displaying of the screen on each update
    char *write;
    char adc_str[10];        
    switch(mode){
        // switches based on the mode set by the keyboard key presses
        case(MODE_DEC):
            // setup the strings to print for the decimal mode
            write = "Decimal value: ";
            int_to_str_dec(adc_res, adc_str);
            break;
        case(MODE_HEX):
            // setup strings to print for the hex mode
            write = "Hex value: ";
            int_to_str_hex(adc_res, adc_str);
            break;
        case(MODE_VOLTAGE_DEC):
            // setup strings to print for the voltage mode
            write = "Voltage value (mV): ";
            uint16_t voltage = adc_to_mvolt(adc_res); 
            int_to_str_dec(voltage, adc_str);
            break;
    } // end switch(mode)
    
    clear_terminal();               // clear the screen
    bar_graph(adc_res, bar_char);   // print the bar graph
    Disp2String(write);             // print the starter string
    Disp2String(adc_str);           // print the value, in whichever form it needs
}


void int_to_str_dec(uint16_t dec, char *str){
    int i = 0;
    if(dec == 0){
        // if the number is just zero, put that in the string and move on
        str[i] = '0';
        i++;    // dont forget to increment the index variable!
    }
    else{
        while(dec > 0){
            // while the number is more than 0, we modulo off the digits and put them in the string
            str[i++] = (dec % 10) + '0';
            dec /= 10;
        }
    }
    
    int start = 0;
    int end = i - 1;
    while(start < end){
        // this loop just reverses the string so its the right order
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end --;
    }
    str[i] = '\0';
    return; 
}


void int_to_str_hex(uint16_t dec, char *str){
    // this function converts an int (dec) to a hex string
    str[0] = '0';
    str[1] = 'x';

    int i = 0;
    char hex[] = "0123456789ABCDEF";    // hex string to index from
    for(i; i < 4; i++){
        uint8_t nibble = (dec >> (12 - 4 * i)) & 0x0F;  // pulls individual nibbles from the decimal int
        str[2 + i] = hex[nibble];   // add it to the string
    }
    str[2 + i] = '\0';
    return;
}


uint16_t adc_to_mvolt(uint16_t adc){
    // converts the raw adc value to a voltage in mV
    uint32_t v;             // the multiplication below may overflow a uint16, so use a uint32 and cast later
    v = adc * AVDD / 1024;  // this just converts the raw adc to a voltage (in mV)
    
    return (uint16_t) v;    // casts the voltage to a uint16 (max is 3V (3000mV) so it fits) and returns 
}


