/* 
 * File:   lab4_functions.h
 * Author: fulbr
 *
 * Created on November 5, 2025, 1:00 PM
 */

#ifndef LAB4_FUNCTIONS_H
#define	LAB4_FUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif

#define debounce_50m 781
#define blink_025   3906
#define AVDD 3000UL       // in mV

// state machine states
typedef enum{ 
    STATE_BEGIN,
    STATE_SAMPLE,
    STATE_DISPLAY,
} state_t;

// mode states
typedef enum{
    MODE_DEC, 
    MODE_HEX, 
    MODE_VOLTAGE_DEC
} mode_t;

extern volatile mode_t mode;
extern volatile char bar_char;

void bar_graph(uint16_t adc_res, char c);
void display_func(uint16_t adc_res, mode_t mode);
void int_to_str_dec(uint16_t dec, char *str);
void int_to_str_hex(uint16_t dec, char *str);
uint16_t adc_to_mvolt(uint16_t adc);
    

#ifdef	__cplusplus
}
#endif

#endif	/* LAB4_FUNCTIONS_H */

