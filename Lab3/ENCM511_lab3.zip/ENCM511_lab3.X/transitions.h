/* 
 * File:   transitions.h
 * Author: fulbr
 *
 * Created on October 24, 2025, 10:39 AM
 */

#ifndef TRANSITIONS_H
#define	TRANSITIONS_H

#ifdef	__cplusplus
extern "C" {
#endif
    
// flags used in multiple places are defined as extern so all places can access them
extern volatile uint16_t debounce_progress;
extern volatile char prog_mode_X;

extern volatile uint16_t PB0_flag;
extern volatile uint16_t PB1_flag;
extern volatile uint16_t PB2_flag;
extern volatile uint16_t dual_flag_01;
extern volatile uint16_t dual_flag_02;
extern volatile uint16_t dual_flag_12;
extern volatile uint16_t trip_flag;
extern volatile uint16_t prog_state;

// blink rate macros
#define blink_0125  1953
#define blink_025   3906
#define blink_05    7812
#define blink_1     15625
#define blink_3     46875
#define debounce_50m 781
    
// state machine states
typedef enum{
    STATE_IDLE,
    STATE_PB0,
    STATE_PB1,
    STATE_PB2,
    STATE_dual
} state_t;

// function prototypes
state_t to_idle(volatile uint16_t *flag, volatile uint16_t prog);
state_t single_press_transition(volatile uint16_t *flag, volatile uint16_t prog);
state_t dual_press_transition();



#ifdef	__cplusplus
}
#endif

#endif	/* TRANSITIONS_H */

