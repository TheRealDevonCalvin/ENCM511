
#include "xc.h"
#include "init.h"
#include "uart.h"
#include "transitions.h"

// initializing all of the extern flags to zero for use here and in main
volatile uint16_t debounce_progress = 0;
volatile char prog_mode_X = 0;

volatile uint16_t PB0_flag = 0;
volatile uint16_t PB1_flag = 0;
volatile uint16_t PB2_flag = 0;
volatile uint16_t dual_flag_01 = 0;
volatile uint16_t dual_flag_02 = 0;
volatile uint16_t dual_flag_12 = 0;
volatile uint16_t trip_flag = 0;
volatile uint16_t prog_state = 0;
volatile uint16_t prog_PB1_blink;




state_t to_idle(volatile uint16_t *flag, volatile uint16_t prog){
    // this function is used to transition the state machine to idle from whichever state it is in
    *flag = 0;              // clear the flag for the button being used to transition to idle
    LED0 = 0;               // turn the LED off
                    
    T3CONbits.TON = 0;      // turn off timer  
               
    if(!prog){
        // if not in prog mode, clear terminal and display the idle fast mode
        clear_terminal();
        Disp2String("\rFast Mode: Idle");
    }
    else if(prog){
        // if in prog mode, clear terminal and display the idle prog mode
        clear_terminal();
        Disp2String("\rProg Mode: Idle");
    }
    return STATE_IDLE;  // put the state machine into the idle state upon return
}


state_t single_press_transition(volatile uint16_t *flag, volatile uint16_t prog){
    // this function handles all transitions that rely on a single button press that do NOT transiiton to idle
    
    state_t temp_state;         // create an intermediate state variable
//    uint16_t prog_PB1_blink;    // a variable to hold the blink rate of PB1 as it relies on user entry
    if(!prog){
        // if NOT in prog mode
        LED0 = 1;       // turn led on to start so it looks cleaner
        char btn;   // to help with the uart writing
        
        if(flag == &PB0_flag){  
            // if PB0 was pressed to cause the transition
            btn = '0';                  // hold char '0' for use in uart display
            PR3 = blink_025;            // initialize timer
            temp_state = STATE_PB0;     // store the temp state (STATE_PB0 because it was what flagged)
        }
        else if(flag == &PB1_flag){
            // same as above except PB1 caused the transition
            btn = '1';
            PR3 = blink_05; 
            temp_state = STATE_PB1;
        }
        else if(flag == &PB2_flag){
            // same as above except PB2 caused the transition
            btn = '2';
            PR3 = blink_1;
            temp_state = STATE_PB2;
        }
        
        // clear the terminal and write the fast mode message to the terminal over uart
        // uses the stored button char from above
        clear_terminal();
        Disp2String("\rFast Mode: PB");
        XmitUART2(btn, 1);
        Disp2String(" was pressed");

        TMR3 = 0;               // set timer start count to 0
        T3CONbits.TON = 1;      // turn on timer
        *flag = 0;              // clear the flag that caused the transition trigger
        return temp_state;      // return the stored state for transition in main()
    }
    else if(prog){
        // if IN prog mode
        if(flag == &PB0_flag){       
            // if PB0 was pressed to cause the transition
            clear_terminal();                           // clear terminal, and display the appropriate message
            Disp2String("\rProg Mode: PB0 was pressed");

            PR3 = blink_3;          // set timer high count 

            temp_state = STATE_PB0; // store temp state for transition later
        }
        else if(flag == &PB1_flag){
            // if PB1 caused the transition, clear terminal and print appropriate message
            clear_terminal();
            Disp2String("\rProg Mode: PB1 was pressed, Setting = ");
            XmitUART2(prog_mode_X, 1);      // this is obtained from the PB2 part of this function(following)
            
            PR3 = prog_PB1_blink;       // set the timer high count to the count given by the user selected setting
            
            temp_state = STATE_PB1;     // store temp state
        }
        else if(flag == &PB2_flag){
            // if PB2 caused the transition, clear terminal and display the user entry prompt
            clear_terminal();
            Disp2String("\rProg Mode: Blink Setting = ");
            
            PR3 = blink_0125;       // while waiting for input, timer blinks at 0.125s (set high count)
            TMR3 = 0;               // set start count
            T3CONbits.TON = 1;      // turn timer on
            *flag = 0;              // clear the flag causing the transition (PB2)
                                    // necessary bc need to use pb2 to store the entered value also

            char rec = RecvUartChar();  // obtain the char from the user

            if(PB2_flag){
                // now if pb2 is pressed to save the value
                if(rec == '0'){     
                    // if user entered 0, set blink rate to 0.25s
                    prog_PB1_blink = blink_025; 
                }
                else if(rec == '1'){
                    // if user entered 1, set blink rate to 0.5s
                    prog_PB1_blink = blink_05;
                }
                else if(rec == '2'){
                    // if user entered 2, set blink rate to 1s
                    prog_PB1_blink = blink_1;
                }
                prog_mode_X = rec;      // store the char for use for the PB1 part of this mode

                // the pb2 press returns us to idle, so clear the terminal and display that
                clear_terminal();
                Disp2String("\rProg Mode: Idle");
                temp_state = STATE_IDLE;    // store the temp state

                // these are just to handle if a button is pressed while we are waiting for the PB2 stuff to finish
                // so we dont get an immediate transition upon exiting                
                PB0_flag = 0;
                PB1_flag = 0;
            }
        }
        // turn on the timer now that the high count is set, and also set the start count to 0
        TMR3 = 0;
        T3CONbits.TON = 1;
        *flag = 0;          // clear the flag that entered us into the function (or PB2 on store value)
        return temp_state;  // return the stored state for transition in main()

    } // end else if (prog)
    
}



state_t dual_press_transition(){
    // this function handles any transitions caused by pressing two buttons at once

    LED0 = 1;           // turn the led on (constant on)
    T3CONbits.TON = 0;  // turn off the timer

    char pb_nums[2];    // to help with the uart writing
    
    if(dual_flag_01){
        // if buttons 0 and 1 were pressed, clear the flag and store their numbers for the uart
        dual_flag_01 = 0;
        pb_nums[0] = '0';
        pb_nums[1] = '1';
    }
    else if(dual_flag_02){
        // same as above, but buttons 0 and 2
        dual_flag_02 = 0;
        pb_nums[0] = '0';
        pb_nums[1] = '2';
    }
    else if(dual_flag_12){
        // same, but buttons 1 and 2
        dual_flag_12 = 0;
        pb_nums[0] = '1';
        pb_nums[1] = '2';
    }

    // clear the terminal and display the appropriate combination of buttons
    clear_terminal();
    Disp2String("\rFast Mode: PB");
    XmitUART2(pb_nums[0], 1);
    Disp2String(" and PB");
    XmitUART2(pb_nums[1], 1);
    Disp2String(" are pressed");
    return STATE_dual;  // return STATE_dual so the fsm transitions in main()
    
}



